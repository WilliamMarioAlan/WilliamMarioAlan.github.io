#define LINUX_PACKAGE_ID " Kali 6.6.15-2kali1"
