#define UTS_MACHINE		"aarch64"
#define LINUX_COMPILE_BY	"devel"
#define LINUX_COMPILE_HOST	"kali.org"
#define LINUX_COMPILER		"gcc-13 (Debian 13.2.0-24) 13.2.0, GNU ld (GNU Binutils for Debian) 2.42"
