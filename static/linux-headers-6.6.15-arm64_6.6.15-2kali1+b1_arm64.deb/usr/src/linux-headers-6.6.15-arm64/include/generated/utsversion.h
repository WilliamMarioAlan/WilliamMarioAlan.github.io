#define UTS_VERSION "#1 SMP Kali 6.6.15-2kali1 (2024-05-17)"
