#define UTS_RELEASE "6.6.15-arm64"
